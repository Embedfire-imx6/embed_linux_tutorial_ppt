#ifndef __CALCULATION_H__
#define __CALCULATION_H__

extern int itype;


int my_add(int a, int b);
int my_sub(int a, int b);

#endif