#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x945ce7d8, "module_layout" },
	{ 0x4a1da23e, "kset_unregister" },
	{ 0xedc03953, "iounmap" },
	{ 0xfbaf3e66, "kobject_put" },
	{ 0x1731d679, "sysfs_create_group" },
	{ 0xf28178a1, "kobject_create_and_add" },
	{ 0x118251af, "kset_create_and_add" },
	{ 0xe97c4103, "ioremap" },
	{ 0x822137e2, "arm_heavy_mb" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x373db350, "kstrtoint" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0x91715312, "sprintf" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "F3A737953B2FE678D054152");
